# Changelog

All notable changes to the **shipwright** Helm chart are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this chart adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

The chart `version` (in `Chart.yaml`) is bumped on **every** chart change,
independent of `appVersion`. CI enforces this with
`ct lint --check-version-increment`. Each release here must mirror the
`artifacthub.io/changes` annotation in `Chart.yaml`.

## [1.0.0]

_First publicly published chart version. New features in this release: externalDatabase and cloudSqlProxy (SWD-1.x). Gateway API networking, cert-manager Certificate, agent-provisioning RBAC, and metrics.provider were shipped in 0.9.0/0.9.1._

### Added

- `externalDatabase` block: bring-your-own-Postgres for the admin service. Set `postgresql.enabled=false` and `externalDatabase.existingSecret` to inject `DATABASE_URL_SHIPWRIGHT_ADMIN` from a user-managed Secret via `secretKeyRef`. The optional `externalDatabase.adminUrlKey` overrides the key name within that Secret (defaults to `DATABASE_URL_SHIPWRIGHT_ADMIN` when empty). When this path is active, the chart-managed admin Secret assembles no DB URL (no duplicate env injection). Bundled-PostgreSQL path is unchanged — this is purely additive.
- `cloudSqlProxy` sidecar: when `cloudSqlProxy.enabled=true`, a GCP Cloud SQL Auth Proxy container is injected alongside the admin container in the admin Deployment, making a Cloud SQL instance reachable at `127.0.0.1:5432`. Disabled by default (`enabled: false`). When enabled, the proxy runs with `--private-ip` and the required `cloudSqlProxy.connectionName` argument. Additional proxy arguments are configurable via `cloudSqlProxy.args`; resource limits via `cloudSqlProxy.resources`. The sidecar is purely additive — the existing admin Deployment is unchanged when the feature is off.

## [0.9.1]

### Added

- `metrics.provider` block: configurable PostHog provider (`posthog.existingSecret`, `posthog.personalApiKeyRef`, `posthog.projectIdRef`) for POSTHOG_PERSONAL_API_KEY / POSTHOG_PROJECT_ID injection via `secretKeyRef`, plus `adminUrl` (METRICS_ADMIN_URL), `basePath` (METRICS_BASE_PATH), `requireOwnerRole` (METRICS_REQUIRE_OWNER_ROLE), and `internalKey.existingSecret` / `internalKey.key` (METRICS_INTERNAL_API_KEY). All fields default to empty/false — existing `SHIPWRIGHT_SESSION_SECRET` and bundled-PG `METRICS_DATABASE_URL` paths are unchanged (additive, gated).

## [0.9.0]

### Added

- Gateway API networking. Setting `networking.type=gateway` renders a
  `gateway.networking.k8s.io/v1` `Gateway` (`templates/gateway.yaml`) and
  `HTTPRoute`(s) (`templates/httproute.yaml`) instead of an Ingress. The Gateway
  binds to a configurable `gatewayClassName` (`networking.gateway.gatewayClassName`,
  default `gke-l7-global-external-managed`) and `host`
  (`networking.gateway.host`, default `shipwright.local`), with a plain HTTP
  listener on `:80`. HTTPRoutes attach via `parentRefs` and route the admin
  UI/API at `/` to the admin Service and the metrics dashboard at `/dashboard`
  to the metrics Service (the `/dashboard` route is omitted when
  `metrics.enabled=false`). Mutually exclusive with `networking.type=ingress`:
  `gateway` renders Gateway+HTTPRoute and NO Ingress, `ingress` renders Ingress
  and NO Gateway/HTTPRoute. Requires the Gateway API CRDs (and a controller for
  the chosen class) in the cluster.
- Optional cert-manager Certificate. Setting `tls.certManager.enabled=true`
  renders a `cert-manager.io/v1` `Certificate` (`templates/certificate.yaml`)
  for `networking.gateway.host`, wired to an `issuerRef`
  (`tls.certManager.issuerRef.{name,kind}`, kind default `ClusterIssuer`). When
  enabled, the Gateway also adds an HTTPS (`:443`) listener referencing the
  issued Secret (`<fullname>-tls`). Disabled by default (Minikube = plain HTTP);
  disabled → no Certificate is rendered.
- `networking.gateway.{gatewayClassName,host,annotations}` and
  `tls.certManager.{enabled,issuerRef.{name,kind}}` values surface, with matching
  `values.schema.json` constraints (`gateway` added to the `networking.type`
  enum; the `certManager` block requires a non-empty `issuerRef.name` when
  enabled).
- Example values file `examples/values-gke-gateway.yaml` demonstrating the full
  `networking.type=gateway` + `tls.certManager.enabled=true` configuration for a
  real GKE cluster (NOT a ct-discovered `ci/` variant, since the kind e2e cluster
  has no Gateway API / cert-manager CRDs).
- Agent-provisioning RBAC + admin env contract, gated on
  `agent.provisioning.enabled` (default **false** → nothing is rendered and the
  admin service stays in **Noop** mode, requiring no cluster access). When
  enabled, the chart renders:
  - A **namespace-scoped** `Role` (`templates/agent-provisioning-rbac.yaml`) —
    NOT a `ClusterRole` — granting least-privilege verbs `create`, `get`,
    `delete` on `apps`/`Deployments` and core (`""`)/`Secrets`: exactly
    the verbs the provisioner (`KubernetesAgentProvisioner`) exercises.
  - A `RoleBinding` binding that Role to the admin `ServiceAccount`.
  - A separate **agent** `ServiceAccount`
    (`templates/agent-serviceaccount.yaml`,
    `agent.provisioning.serviceAccount.{create,name,annotations}`) that
    provisioned agent pods run as — distinct from the admin SA.
  - The provisioner **env contract** injected into the admin Deployment,
    matching `admin/src/main.ts` `buildProvisioner` exactly:
    `SHIPWRIGHT_K8S_PROVISIONING=enabled`, `SHIPWRIGHT_K8S_NAMESPACE` (via the
    **downward API**, `fieldRef: metadata.namespace`), `SHIPWRIGHT_AGENT_IMAGE`
    + `SHIPWRIGHT_AGENT_IMAGE_TAG` (tag defaults to `.Chart.AppVersion`),
    `SHIPWRIGHT_AGENT_REPLICAS`, `SHIPWRIGHT_API_URL` (built from the admin
    Service name + port, or `agent.provisioning.apiUrl`), and
    `SHIPWRIGHT_ADMIN_DEPLOYMENT_NAME`. `SHIPWRIGHT_ADMIN_DEPLOYMENT_UID` is
    injected ONLY when `agent.provisioning.adminDeploymentUid` is set — the
    downward API cannot expose the parent Deployment's UID to its pods, so a
    missing UID is acceptable (ownerRef propagation is a separate follow-up) and
    no wrong value is fabricated.
  - New values: `agent.provisioning.{enabled, image.{repository,tag}, replicas,
    serviceAccount.{create,name,annotations}, apiUrl, adminDeploymentUid,
    pvc.{size,storageClass}}` (provisioning OFF by default). The `pvc` settings
    are surfaced for the agent manifest builder's future use and are NOT injected
    as env (not read by `buildProvisioner`).

## [0.6.0]

### Added

- Ingress networking. Setting `networking.type=ingress` renders a
  `networking.k8s.io/v1` `Ingress` (`templates/ingress.yaml`) with a configurable
  `ingressClassName` (`networking.ingress.className`, default `nginx`), `host`
  (`networking.ingress.host`, default `shipwright.local`), and controller-specific
  `annotations` (`networking.ingress.annotations`, default `{}`). Rules route the
  admin UI/API at `/` to the admin Service and the metrics dashboard at `/dashboard`
  to the metrics Service (`pathType: Prefix`). The `/dashboard` path is omitted when
  `metrics.enabled=false`. No Ingress is rendered for any other `networking.type`
  (the default stays `ClusterIP`, so the Ingress is OFF by default).
- Helm test connection hook (`templates/tests/test-connection.yaml`). A
  `helm.sh/hook: test` Pod using the public, pinned `curlimages/curl` image curls
  the admin Service `/health` (must return 200) and, when `metrics.enabled`, the
  metrics Service `/dashboard` (accepts 200 or 302), exiting non-zero on failure so
  `helm test` fails loudly. This is the smoke check `ct install` runs in the e2e job.

## [0.5.0]

### Fixed

- Initdb DB name now tracks `metrics.database.name` overrides. The hardcoded
  `shipwright_metrics` string in `postgresql.primary.initdb.scripts` has been
  replaced with a parent-chart ConfigMap (`metrics-initdb-configmap.yaml`)
  rendered via the `shipwright.metrics.databaseName` helper. The Bitnami subchart
  reads the ConfigMap name from `postgresql.primary.initdb.scriptsConfigMap`
  (evaluated through `tpl` at install time using `.Release.Name`). Previously,
  overriding `metrics.database.name` would cause a fresh install to fail because
  the Deployment targeted a database that initdb never created.

## [0.4.0]

### Added

- Metrics service workloads: `metrics-deployment.yaml`, `metrics-service.yaml`,
  and `metrics-serviceaccount.yaml` (container port 3460, liveness/readiness
  probes on the DB-independent `/health`, ServiceAccount, standard
  labels/selectors). The dashboard is served at `/dashboard`.
- Chart-managed metrics `Secret` (`metrics-secret.yaml`) assembling
  `METRICS_DATABASE_URL` for postgres mode so the database password is never
  rendered into plaintext Deployment env. Only rendered when both `metrics.enabled`
  and `postgresql.enabled` are true.
- `METRICS_DATABASE_URL` wired to the bundled Bitnami PostgreSQL subchart in
  postgres mode (`METRICS_OFFLINE=false`, `METRICS_API_PORT=3460`). The metrics
  provider bootstraps its own `events` table on boot — no separate migration job.
- `metrics.service.type`, `metrics.serviceAccount.{create,name,annotations}`,
  `metrics.resources`, and `metrics.database.name` values surface, with matching
  `values.schema.json` constraints. `metrics.database.name` empty reuses the
  bundled PostgreSQL database (no collision with the admin Prisma tables); set it
  to isolate metrics data in a separate database.
- CI: the `helm-e2e` workflow now builds and side-loads the `shipwright-metrics`
  image into kind so `ct install` schedules the real metrics workload.

## [0.3.0]

### Added

- Admin service workloads: `admin-deployment.yaml`, `admin-service.yaml`, and
  `admin-serviceaccount.yaml` (container port 3001, liveness/readiness probes on
  `/health`, ServiceAccount, standard labels/selectors).
- Chart-managed admin `Secret` (`admin-secret.yaml`) holding
  `SHIPWRIGHT_SESSION_SECRET` and `SHIPWRIGHT_ENCRYPTION_KEY`, generated with the
  lookup-then-`randAlphaNum` idiom so they survive `helm upgrade`.
- `DATABASE_URL_SHIPWRIGHT_ADMIN` wired to the bundled Bitnami PostgreSQL
  subchart. The URL is assembled in the admin Secret so the database password is
  never rendered into plaintext Deployment env.
- Auth modes for the admin service: `open` (dev auth via `ADMIN_DEV_AUTH=true`,
  **insecure — no real authentication**) and `google` (Google OAuth with
  `NODE_ENV=production`, `GOOGLE_CLIENT_ID/SECRET`, and
  `SHIPWRIGHT_ADMIN_ALLOWED_EMAILS`).
- `admin.service.type`, `admin.serviceAccount.{create,name,annotations}`,
  `admin.resources`, and the `auth.google.{clientId,clientSecret,allowedEmails}`
  values surface, with matching `values.schema.json` constraints.

### Changed

- `auth.mode` enum is now `open | google` (was `none | session | bearer`); the
  default is `open`. NOTES.txt warns loudly when `auth.mode=open`.
  **Migration:** existing installs with `auth.mode: none` should run
  `helm upgrade --set auth.mode=open` or add `auth.mode: open` to their values
  file. The value `none` is retained as a deprecated alias for `open` and will
  be removed in a future release.
- CI values variants (`ci/*-values.yaml`) updated to the new auth modes (gke
  exercises `google`, minikube/eks exercise `open`).

## [0.2.0]

### Added

- `CHANGELOG.md` (keep-a-changelog) documenting chart versions.
- `artifacthub.io/changes` annotation in `Chart.yaml` mirroring this changelog.
- `ct` version-increment CI gate (`ct lint --check-version-increment`) wired into
  the Helm workflow — any PR touching `charts/shipwright/**` that does not bump
  the chart `version` now fails CI.

### Changed

- Documented the chart versioning discipline in the chart `README.md`
  ("Versioning" section) and `CONTRIBUTING.md`.

## [0.1.0]

### Added

- Initial chart scaffold: values surface, helpers, NOTES, `values.schema.json`,
  and the pinned Bitnami PostgreSQL dependency (HD-2.1).
- Helm test harness: `task helm:*` targets, helm-unittest specs, and the
  kind-based `ct install` CI workflow (HD-2.2).
