{{/*
Admin Deployment. Include from a stub file in the consuming chart; reads .Values.admin, .Values.auth, .Values.agent, ...
*/}}
{{- define "agent-platform.admin.deployment" -}}
{{- /*
agent-platform.validate.anthropicFederation is included unconditionally so the
federation guards fire on every manifest render, even with admin disabled.
*/}}
{{- include "agent-platform.validate.anthropicFederation" . }}
{{- if .Values.admin.enabled }}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "agent-platform.admin.fullname" . }}
  labels:
    {{- include "agent-platform.admin.labels" . | nindent 4 }}
spec:
  replicas: {{ .Values.admin.replicas | default 1 }}
  selector:
    matchLabels:
      {{- include "agent-platform.admin.selectorLabels" . | nindent 6 }}
  template:
    metadata:
      {{- $selectorLabels := include "agent-platform.admin.selectorLabels" . }}
      labels:
        {{- $selectorLabels | nindent 8 }}
        {{- with (include "agent-platform.podLabels" (dict "podLabels" .Values.admin.podLabels "selectorLabels" $selectorLabels)) }}
        {{- . | nindent 8 }}
        {{- end }}
      {{- with .Values.admin.podAnnotations }}
      annotations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
    spec:
      serviceAccountName: {{ include "agent-platform.admin.serviceAccountName" . }}
      {{- with .Values.global.imagePullSecrets }}
      imagePullSecrets:
        {{- range . }}
        - name: {{ . }}
        {{- end }}
      {{- end }}
      {{- if or .Values.postgresql.enabled (and .Values.cloudSqlProxy.enabled .Values.cloudSqlProxy.nativeSidecar) }}
      initContainers:
      {{- if .Values.postgresql.enabled }}
        - name: wait-for-postgres
          image: busybox:1.36
          command: ['sh', '-c', 'until nc -z {{ include "agent-platform.postgresql.fullname" . }} 5432; do echo "waiting for postgresql..."; sleep 2; done']
      {{- end }}
      {{- if and .Values.cloudSqlProxy.enabled .Values.cloudSqlProxy.nativeSidecar }}
        {{- include "agent-platform.cloudSqlProxy.container" (dict "context" $ "nativeSidecar" true) | nindent 8 }}
      {{- end }}
      {{- end }}
      containers:
        - name: admin
          image: {{ include "agent-platform.imageRef" (dict "context" $ "repository" .Values.admin.image.repository "tag" (.Values.admin.image.tag | default .Chart.AppVersion)) | quote }}
          imagePullPolicy: {{ .Values.admin.image.pullPolicy | default .Values.imagePullPolicy }}
          ports:
            - name: http
              containerPort: 3001
              protocol: TCP
          livenessProbe:
            # DB-independent — a transient DB blip must never trigger a
            # liveness-driven restart of an otherwise-healthy process.
            httpGet:
              path: /health
              port: 3001
            initialDelaySeconds: 10
            periodSeconds: 15
            timeoutSeconds: 3
            failureThreshold: 3
          readinessProbe:
            # DB-aware — keeps the pod out of Service rotation until the Cloud
            # SQL proxy sidecar has finished connecting to Postgres.
            httpGet:
              path: /health/ready
              port: 3001
            initialDelaySeconds: 5
            periodSeconds: 10
            timeoutSeconds: 3
            failureThreshold: 3
            successThreshold: 2
          env:
            # Bind the admin service to the chart-standard port 3001 (the app
            # defaults to 3000 via PORT; the chart standardizes on 3001).
            - name: PORT
              value: "3001"
            {{- if .Values.postgresql.enabled }}
            # Assembled in the admin Secret so the Postgres password is never in
            # plaintext Deployment env.
            - name: DATABASE_URL_SHIPWRIGHT_ADMIN
              valueFrom:
                secretKeyRef:
                  name: {{ include "agent-platform.admin.secretName" . }}
                  key: DATABASE_URL_SHIPWRIGHT_ADMIN
            {{- else if and (not .Values.postgresql.enabled) (empty .Values.externalDatabase.existingSecret) }}
            {{- fail "externalDatabase.existingSecret is required when postgresql.enabled=false" }}
            {{- else if .Values.externalDatabase.existingSecret }}
            # Bring-your-own (external) Postgres: inject DATABASE_URL_SHIPWRIGHT_ADMIN
            # from a user-managed Secret. The chart neither assembles nor owns this
            # Secret, so the admin Secret stays free of any DB URL (no duplicate env).
            # adminUrlKey defaults to DATABASE_URL_SHIPWRIGHT_ADMIN when left empty.
            - name: DATABASE_URL_SHIPWRIGHT_ADMIN
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.externalDatabase.existingSecret }}
                  key: {{ .Values.externalDatabase.adminUrlKey | default "DATABASE_URL_SHIPWRIGHT_ADMIN" }}
            {{- end }}
            {{- if .Values.admin.encryptionKeys.existingSecret }}
            # admin.encryptionKeys.existingSecret: source these two keys from a
            # caller-managed Secret so they survive across fresh namespace installs
            # without generating random values that can't decrypt existing data.
            - name: SHIPWRIGHT_SESSION_SECRET
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.admin.encryptionKeys.existingSecret }}
                  key: {{ .Values.admin.encryptionKeys.sessionSecretRef | default "SHIPWRIGHT_SESSION_SECRET" }}
            - name: SHIPWRIGHT_ENCRYPTION_KEY
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.admin.encryptionKeys.existingSecret }}
                  key: {{ .Values.admin.encryptionKeys.encryptionKeyRef | default "SHIPWRIGHT_ENCRYPTION_KEY" }}
            {{- else }}
            - name: SHIPWRIGHT_SESSION_SECRET
              valueFrom:
                secretKeyRef:
                  name: {{ include "agent-platform.admin.secretName" . }}
                  key: SHIPWRIGHT_SESSION_SECRET
            - name: SHIPWRIGHT_ENCRYPTION_KEY
              valueFrom:
                secretKeyRef:
                  name: {{ include "agent-platform.admin.secretName" . }}
                  key: SHIPWRIGHT_ENCRYPTION_KEY
            {{- end }}
            {{- $adminAppBaseUrl := include "agent-platform.admin.appBaseUrl" . }}
            {{- if $adminAppBaseUrl }}
            # admin.appBaseUrl: public host for OAuth redirect URIs so they use
            # the real hostname instead of localhost:3001. An explicit
            # admin.appBaseUrl always wins; otherwise it's auto-derived from
            # the public host for networking.type=ingress/gateway (see
            # shipwright.admin.appBaseUrl); omitted entirely for
            # ClusterIP/NodePort/LoadBalancer.
            - name: SHIPWRIGHT_ADMIN_APP_BASE_URL
              value: {{ $adminAppBaseUrl | quote }}
            {{- end }}
            {{- if or (eq .Values.auth.mode "open") (eq .Values.auth.mode "none") }}
            # auth.mode=open (or deprecated alias "none") — dev auth, NO OAuth.
            # Insecure: do not expose publicly. NODE_ENV must be explicitly
            # overridden to a non-production value: the admin image bakes
            # NODE_ENV=production (admin/Dockerfile), which would hard-block the
            # dev-auth path if left to the image default.
            - name: NODE_ENV
              value: "development"
            - name: ADMIN_DEV_AUTH
              value: "true"
            {{- else if eq .Values.auth.mode "google" }}
            # auth.mode=google — real Google OAuth. Production hardening on.
            - name: NODE_ENV
              value: "production"
            {{- if .Values.auth.google.existingSecret }}
            # auth.google.existingSecret: source all three OAuth vars from caller-managed Secret.
            - name: GOOGLE_CLIENT_ID
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.auth.google.existingSecret }}
                  key: {{ .Values.auth.google.clientIdRef | default "GOOGLE_CLIENT_ID" }}
            - name: GOOGLE_CLIENT_SECRET
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.auth.google.existingSecret }}
                  key: {{ .Values.auth.google.clientSecretRef | default "GOOGLE_CLIENT_SECRET" }}
            - name: SHIPWRIGHT_ADMIN_ALLOWED_EMAILS
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.auth.google.existingSecret }}
                  key: {{ .Values.auth.google.allowedEmailsRef | default "SHIPWRIGHT_ADMIN_ALLOWED_EMAILS" }}
            {{- else }}
            - name: GOOGLE_CLIENT_ID
              valueFrom:
                secretKeyRef:
                  name: {{ include "agent-platform.admin.secretName" . }}
                  key: GOOGLE_CLIENT_ID
            - name: GOOGLE_CLIENT_SECRET
              valueFrom:
                secretKeyRef:
                  name: {{ include "agent-platform.admin.secretName" . }}
                  key: GOOGLE_CLIENT_SECRET
            - name: SHIPWRIGHT_ADMIN_ALLOWED_EMAILS
              value: {{ .Values.auth.google.allowedEmails | quote }}
            {{- end }}
            {{- else if eq .Values.auth.mode "okta" }}
            # auth.mode=okta — Okta OIDC env wiring (chart-only; admin app has
            # no Okta login handler yet, see values.yaml auth.mode comment).
            # Production hardening (NODE_ENV=production) on regardless.
            - name: NODE_ENV
              value: "production"
            {{- if .Values.auth.okta.existingSecret }}
            # auth.okta.existingSecret: source all four OIDC vars from caller-managed Secret.
            - name: OKTA_ISSUER
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.auth.okta.existingSecret }}
                  key: {{ .Values.auth.okta.issuerRef | default "OKTA_ISSUER" }}
            - name: OKTA_CLIENT_ID
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.auth.okta.existingSecret }}
                  key: {{ .Values.auth.okta.clientIdRef | default "OKTA_CLIENT_ID" }}
            - name: OKTA_CLIENT_SECRET
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.auth.okta.existingSecret }}
                  key: {{ .Values.auth.okta.clientSecretRef | default "OKTA_CLIENT_SECRET" }}
            - name: SHIPWRIGHT_ADMIN_ALLOWED_EMAILS
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.auth.okta.existingSecret }}
                  key: {{ .Values.auth.okta.allowedEmailsRef | default "SHIPWRIGHT_ADMIN_ALLOWED_EMAILS" }}
            {{- else }}
            - name: OKTA_ISSUER
              valueFrom:
                secretKeyRef:
                  name: {{ include "agent-platform.admin.secretName" . }}
                  key: OKTA_ISSUER
            - name: OKTA_CLIENT_ID
              valueFrom:
                secretKeyRef:
                  name: {{ include "agent-platform.admin.secretName" . }}
                  key: OKTA_CLIENT_ID
            - name: OKTA_CLIENT_SECRET
              valueFrom:
                secretKeyRef:
                  name: {{ include "agent-platform.admin.secretName" . }}
                  key: OKTA_CLIENT_SECRET
            - name: SHIPWRIGHT_ADMIN_ALLOWED_EMAILS
              value: {{ .Values.auth.okta.allowedEmails | quote }}
            {{- end }}
            {{- end }}
            {{- if .Values.agent.provisioning.enabled }}
            # ── Agent-provisioning env contract (HD-4.2) ──────────────────────
            # Injected ONLY when agent.provisioning.enabled. These are exactly the
            # vars admin/src/main.ts buildProvisioner reads — when absent (default),
            # main.ts returns a NoopAgentProvisioner (no cluster access). Do not add
            # vars main.ts ignores.
            - name: SHIPWRIGHT_K8S_PROVISIONING
              value: "enabled"
            # Namespace for provisioned agent resources. When agent.provisioning.namespace
            # is set, use the explicit value (cross-namespace provisioning). Otherwise
            # fall back to the downward API (pod's own release namespace = zero-config default).
            {{- if .Values.agent.provisioning.namespace }}
            - name: SHIPWRIGHT_K8S_NAMESPACE
              value: {{ .Values.agent.provisioning.namespace | quote }}
            {{- else }}
            - name: SHIPWRIGHT_K8S_NAMESPACE
              valueFrom:
                fieldRef:
                  fieldPath: metadata.namespace
            {{- end }}
            - name: SHIPWRIGHT_AGENT_IMAGE
              value: {{ .Values.agent.provisioning.image.repository | quote }}
            - name: SHIPWRIGHT_AGENT_IMAGE_TAG
              value: {{ .Values.agent.provisioning.image.tag | default .Chart.AppVersion | quote }}
            - name: SHIPWRIGHT_AGENT_REPLICAS
              value: {{ .Values.agent.provisioning.replicas | quote }}
            # In-cluster admin/gateway URL the provisioner hands to agent pods.
            # Defaults to the admin Service DNS name + port; override via
            # agent.provisioning.apiUrl for an external gateway.
            - name: SHIPWRIGHT_API_URL
              value: {{ .Values.agent.provisioning.apiUrl | default (printf "http://%s:%v" (include "agent-platform.admin.fullname" .) .Values.admin.service.port) | quote }}
            {{- if .Values.agent.provisioning.claudePolicy.enabled }}
            # Managed Claude Code policy (ACP-2.1): ConfigMap name + sha256 of the
            # rendered managed-settings.json (changes roll agent pods).
            - name: SHIPWRIGHT_K8S_AGENT_CLAUDE_POLICY_CONFIGMAP
              value: {{ include "agent-platform.agent.claudePolicy.configMapName" . | quote }}
            - name: SHIPWRIGHT_K8S_AGENT_CLAUDE_POLICY_HASH
              value: {{ include "agent-platform.agent.claudePolicy.json" . | sha256sum | quote }}
            {{- end }}
            {{- with .Values.agent.provisioning.anthropicFederation }}
            {{- if and .enabled (eq (.identityMode | default "shared") "perAgent") }}
            # Anthropic perAgent identity mode: the provisioner reads the mode,
            # issuer and name suffix (admin/src/main.ts parseAnthropicFederation);
            # the shared rule/service-account env is intentionally not rendered.
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_IDENTITY_MODE
              value: perAgent
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_ISSUER_ID
              value: {{ .issuerId | quote }}
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_ORGANIZATION_ID
              value: {{ .organizationId | quote }}
            {{- with .nameSuffix }}
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_NAME_SUFFIX
              value: {{ . | quote }}
            {{- end }}
            {{- with .workspaceId }}
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_WORKSPACE_ID
              value: {{ . | quote }}
            {{- end }}
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_AUDIENCE
              value: {{ .audience | quote }}
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_TOKEN_EXPIRATION_SECONDS
              value: {{ .tokenExpirationSeconds | int64 | quote }}
            # The admin pod's own federation: the projected token mounted below is
            # exchanged (via the org:admin bootstrap rule) for Admin API access.
            - name: ANTHROPIC_IDENTITY_TOKEN_FILE
              value: /var/run/secrets/anthropic.com/token
            - name: ANTHROPIC_FEDERATION_RULE_ID
              value: {{ .adminFederation.ruleId | quote }}
            - name: ANTHROPIC_ORGANIZATION_ID
              value: {{ .organizationId | quote }}
            - name: ANTHROPIC_SERVICE_ACCOUNT_ID
              value: {{ .adminFederation.serviceAccountId | quote }}
            {{- with .workspaceId }}
            - name: ANTHROPIC_WORKSPACE_ID
              value: {{ . | quote }}
            {{- end }}
            {{- else if .enabled }}
            # Anthropic workload identity federation: agent pods run as the agent
            # ServiceAccount with a projected token exchanged for Anthropic access.
            # RULE_ID gates the feature in admin/src/main.ts parseAnthropicFederation.
            - name: SHIPWRIGHT_K8S_AGENT_SERVICE_ACCOUNT
              value: {{ include "agent-platform.agent.serviceAccountName" $ | quote }}
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_RULE_ID
              value: {{ .federationRuleId | quote }}
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_ORGANIZATION_ID
              value: {{ .organizationId | quote }}
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_SERVICE_ACCOUNT_ID
              value: {{ .serviceAccountId | quote }}
            {{- with .workspaceId }}
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_WORKSPACE_ID
              value: {{ . | quote }}
            {{- end }}
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_AUDIENCE
              value: {{ .audience | quote }}
            - name: SHIPWRIGHT_K8S_AGENT_ANTHROPIC_FEDERATION_TOKEN_EXPIRATION_SECONDS
              value: {{ .tokenExpirationSeconds | int64 | quote }}
            {{- end }}
            {{- end }}
            {{- with .Values.agent.provisioning.pvcNameTemplate }}
            # PVC name template: when set, the provisioner substitutes {name} with
            # the agent's human-readable name (slug) to derive the PVC name. Used
            # when migrating from static agents with fixed naming conventions.
            - name: SHIPWRIGHT_AGENT_PVC_NAME_TEMPLATE
              value: {{ . | quote }}
            {{- end }}
            # Per-field container resource overrides for the provisioned agent.
            # Each renders only when set; unset fields keep the provisioner's own
            # built-in defaults (@app-vitals/agent-admin/agent-manifest).
            {{- with .Values.agent.provisioning.resources.requests.cpu }}
            - name: SHIPWRIGHT_K8S_AGENT_CPU_REQUEST
              value: {{ . | quote }}
            {{- end }}
            {{- with .Values.agent.provisioning.resources.limits.cpu }}
            - name: SHIPWRIGHT_K8S_AGENT_CPU_LIMIT
              value: {{ . | quote }}
            {{- end }}
            {{- with .Values.agent.provisioning.resources.requests.memory }}
            - name: SHIPWRIGHT_K8S_AGENT_MEMORY_REQUEST
              value: {{ . | quote }}
            {{- end }}
            {{- with .Values.agent.provisioning.resources.limits.memory }}
            - name: SHIPWRIGHT_K8S_AGENT_MEMORY_LIMIT
              value: {{ . | quote }}
            {{- end }}
            {{- with .Values.agent.provisioning.resources.ephemeralStorage }}
            - name: SHIPWRIGHT_K8S_AGENT_EPHEMERAL_STORAGE
              value: {{ . | quote }}
            {{- end }}
            {{- end }}
            {{- if .Values.agent.voice.enabled }}
            # ── Agent-voice env contract (CV-1.1) ─────────────────────────────
            # Injected ONLY when agent.voice.enabled. admin/src/main.ts
            # buildProvisioner reads these and flows them into every provisioned
            # agent pod (agent/src/runtime/config.ts reads the same names). When voice is
            # disabled none of these render and provisioned pods keep the 3 base
            # vars only.
            {{- if eq .Values.agent.voice.provider "whisper" }}
            # provider=whisper → the in-cluster Whisper Service URL (POST /asr).
            - name: WHISPER_SERVICE_URL
              value: {{ include "agent-platform.whisper.serviceUrl" . | quote }}
            {{- else if eq .Values.agent.voice.provider "groq" }}
            # provider=groq → GROQ_API_KEY sourced from the chart-managed voice
            # Secret so the key is never in plaintext Deployment env.
            {{- if .Values.agent.voice.groq.apiKey }}
            - name: GROQ_API_KEY
              valueFrom:
                secretKeyRef:
                  name: {{ include "agent-platform.voice.secretName" . }}
                  key: GROQ_API_KEY
            {{- end }}
            {{- end }}
            # ElevenLabs TTS (both providers). Key via the voice Secret; the
            # optional voice id is non-secret plain env.
            {{- if .Values.agent.voice.elevenlabs.apiKey }}
            - name: ELEVENLABS_API_KEY
              valueFrom:
                secretKeyRef:
                  name: {{ include "agent-platform.voice.secretName" . }}
                  key: ELEVENLABS_API_KEY
            {{- end }}
            {{- with .Values.agent.voice.elevenlabs.voiceId }}
            - name: ELEVENLABS_VOICE_ID
              value: {{ . | quote }}
            {{- end }}
            {{- end }}
            {{- with (include "agent-platform.chat.adminTokenSecretName" .) }}
            # ── Chat-service wiring ───────────────────────────────────────────
            # Enables the admin console's Chat tab (/admin/chat) and per-agent
            # chat-token minting during provisioning. The URL is the in-cluster
            # chat Service; the token is the same raw value the chat service
            # seeds at boot via CHAT_SEED_ADMIN_TOKEN, so the pair works out of
            # the box — from the caller's chat.adminToken.existingSecret when
            # set, otherwise from the chart-managed chat Secret. Override the
            # URL via admin.extraEnv if needed (extraEnv is appended last and
            # wins).
            - name: SHIPWRIGHT_CHAT_SERVICE_URL
              value: {{ printf "http://%s:%v" (include "agent-platform.chat.fullname" $) $.Values.chat.service.port | quote }}
            - name: SHIPWRIGHT_CHAT_SERVICE_ADMIN_TOKEN
              valueFrom:
                secretKeyRef:
                  name: {{ . }}
                  key: {{ include "agent-platform.chat.adminTokenSecretKey" $ }}
            {{- end }}
            {{- if .Values.admin.sentry.dsn.existingSecret }}
            - name: SENTRY_DSN
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.admin.sentry.dsn.existingSecret }}
                  key: {{ .Values.admin.sentry.dsn.key | default "SENTRY_DSN" }}
            {{- end }}
            {{- if .Values.admin.sentry.environment }}
            - name: SENTRY_ENVIRONMENT
              value: {{ .Values.admin.sentry.environment | quote }}
            {{- end }}
            {{- with .Values.selfServe }}
            {{- if .enabled }}
            # ── Self-serve provisioning env (SSP-1.3) ─────────────────────────
            # Injected ONLY when selfServe.enabled. Read by @app-vitals/agent-admin/self-serve-config.
            - name: SHIPWRIGHT_SELF_SERVE_ENABLED
              value: "enabled"
            - name: SHIPWRIGHT_SELF_SERVE_DEFAULT_MAX_AGENTS
              value: {{ .defaultMaxAgents | default 0 | quote }}
            - name: SHIPWRIGHT_SELF_SERVE_CONTACT_EMAIL
              value: {{ .contactEmail | quote }}
            {{- end }}
            {{- end }}
            {{- with .Values.admin.ask }}
            {{- if .enabled }}
            # ── Agent ask feature flag
            - name: SHIPWRIGHT_AGENT_ASK_ENABLED
              value: "enabled"
            - name: SHIPWRIGHT_AGENT_ASK_ALLOWLIST
              value: {{ join "," .allowlist | quote }}
            {{- end }}
            {{- end }}
            {{- with .Values.admin.chatCredentialMint }}
            {{- if .enabled }}
            # ── Chat credential mint feature flag
            - name: SHIPWRIGHT_CHAT_TOKEN_MINT_ENABLED
              value: "enabled"
            {{- end }}
            {{- end }}
            {{- with .Values.admin.doc }}
            {{- if .enabled }}
            # ── Admin documentation feature flag
            - name: SHIPWRIGHT_ADMIN_DOC_ENABLED
              value: "enabled"
            {{- end }}
            {{- end }}
            {{- with .Values.admin.podServiceAccount }}
            {{- if .enabled }}
            # ── Pod ServiceAccount feature flag
            - name: SHIPWRIGHT_K8S_AGENT_POD_SERVICE_ACCOUNT_ENABLED
              value: "enabled"
            {{- end }}
            {{- end }}
            {{- with .Values.admin.cronRunNow }}
            {{- if .enabled }}
            # ── Cron run-now feature flag
            - name: SHIPWRIGHT_CRON_RUN_NOW_ENABLED
              value: "enabled"
            {{- end }}
            {{- end }}
            {{- with .Values.admin.transcriptApi }}
            {{- if .enabled }}
            # ── Cron-run transcript API feature flag
            - name: SHIPWRIGHT_TRANSCRIPT_API_ENABLED
              value: "enabled"
            {{- end }}
            {{- end }}
            {{- with .Values.admin.repoAccessCheck }}
            {{- if .enabled }}
            # ── Agent repo-access check feature flag
            - name: SHIPWRIGHT_AGENT_REPO_ACCESS_CHECK_ENABLED
              value: "enabled"
            {{- end }}
            {{- end }}
            {{- with .Values.admin.extraEnv }}
            # admin.extraEnv: caller-supplied env vars appended last so they can
            # override anything above if needed.
            {{- toYaml . | nindent 12 }}
            {{- end }}
          {{- with .Values.admin.resources }}
          resources:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with .Values.agent.provisioning.anthropicFederation }}
          {{- if and .enabled (eq (.identityMode | default "shared") "perAgent") }}
          volumeMounts:
            - name: anthropic-token
              mountPath: /var/run/secrets/anthropic.com
              readOnly: true
          {{- end }}
          {{- end }}
        {{- if and .Values.cloudSqlProxy.enabled (not .Values.cloudSqlProxy.nativeSidecar) }}
        {{- include "agent-platform.cloudSqlProxy.container" (dict "context" $ "nativeSidecar" false) | nindent 8 }}
        {{- end }}
      {{- with .Values.agent.provisioning.anthropicFederation }}
      {{- if and .enabled (eq (.identityMode | default "shared") "perAgent") }}
      volumes:
        # Projected ServiceAccount token for the admin pod's own Anthropic
        # federation (perAgent mode only).
        - name: anthropic-token
          projected:
            sources:
              - serviceAccountToken:
                  audience: {{ .audience | quote }}
                  expirationSeconds: {{ .tokenExpirationSeconds | int64 }}
                  path: token
      {{- end }}
      {{- end }}
{{- end }}
{{- end }}

{{/*
Admin Service.
*/}}
{{- define "agent-platform.admin.service" -}}
{{- if .Values.admin.enabled }}
apiVersion: v1
kind: Service
metadata:
  name: {{ include "agent-platform.admin.fullname" . }}
  labels:
    {{- include "agent-platform.admin.labels" . | nindent 4 }}
spec:
  type: {{ .Values.admin.service.type | default "ClusterIP" }}
  ports:
    - name: http
      port: {{ .Values.admin.service.port }}
      targetPort: 3001
      protocol: TCP
  selector:
    {{- include "agent-platform.admin.selectorLabels" . | nindent 4 }}
{{- end }}
{{- end }}

{{/*
Chart-managed admin Secret (session/encryption keys, assembled DATABASE_URL, OAuth credentials).
*/}}
{{- define "agent-platform.admin.secret" -}}
{{- if .Values.admin.enabled }}
{{- /*
  Chart-managed admin Secret.

  Holds the admin session/encryption keys (unless admin.encryptionKeys.existingSecret
  is set — then the Deployment references that external Secret directly and those keys
  are omitted here), and — when the bundled PostgreSQL subchart is enabled — the
  fully-assembled DATABASE_URL_SHIPWRIGHT_ADMIN so the Postgres password never appears
  in plaintext Deployment env.

  Persistence idiom for chart-generated keys (survives `helm upgrade`): look up the
  already-installed Secret and reuse its (already base64-encoded) values; only generate
  fresh random material on first install. NOTE: `helm template` and helm-unittest do NOT
  execute `lookup`, so they always take the generate branch — that is expected. On a
  live install/upgrade the lookup finds the prior Secret and the generated values stay
  stable.

  When admin.encryptionKeys.existingSecret is set the generate/lookup path is skipped
  entirely and no key material is written here — the Deployment uses secretKeyRef
  against the caller-managed Secret for those two vars.
*/}}
{{- $secretName := include "agent-platform.admin.secretName" . }}
{{- $existing := (lookup "v1" "Secret" .Release.Namespace $secretName) }}
{{- $sessionSecret := "" }}
{{- $encryptionKey := "" }}
{{- if not .Values.admin.encryptionKeys.existingSecret }}
{{- if and $existing $existing.data (index $existing.data "SHIPWRIGHT_SESSION_SECRET") }}
{{- $sessionSecret = index $existing.data "SHIPWRIGHT_SESSION_SECRET" }}
{{- else }}
{{- $sessionSecret = (randAlphaNum 32 | b64enc) }}
{{- end }}
{{- if and $existing $existing.data (index $existing.data "SHIPWRIGHT_ENCRYPTION_KEY") }}
{{- $encryptionKey = index $existing.data "SHIPWRIGHT_ENCRYPTION_KEY" }}
{{- else }}
{{- /*
  crypto.ts decodes this via Buffer.from(key, "hex") and requires a 64-char hex
  string (32 bytes for AES-256-GCM). `randAlphaNum 32` alone yields a 32-char
  value that fails as "Invalid key length"; sha256sum turns random material into
  exactly 64 hex chars. (SESSION_SECRET above is never hex-decoded, so its
  randAlphaNum form is fine.)
*/}}
{{- $encryptionKey = (randAlphaNum 32 | sha256sum | b64enc) }}
{{- end }}
{{- end }}
apiVersion: v1
kind: Secret
metadata:
  name: {{ $secretName }}
  labels:
    {{- include "agent-platform.admin.labels" . | nindent 4 }}
type: Opaque
data:
{{- if not .Values.admin.encryptionKeys.existingSecret }}
  # Generated on first install, reused on upgrade via the lookup idiom above.
  # Omitted when admin.encryptionKeys.existingSecret is set — the Deployment
  # sources these vars from the caller-managed Secret instead.
  SHIPWRIGHT_SESSION_SECRET: {{ $sessionSecret | quote }}
  SHIPWRIGHT_ENCRYPTION_KEY: {{ $encryptionKey | quote }}
{{- end }}
{{- if .Values.postgresql.enabled }}
  {{- /*
    Assemble DATABASE_URL_SHIPWRIGHT_ADMIN here so the Postgres password is not
    rendered into the Deployment's plaintext env. Password resolution lives in
    the shared agent-platform.postgresql.password helper — see it for the resolution
    order and for why the Bitnami Secret key is `password` (this chart used to
    look up a `postgresql-password` key that Bitnami has never emitted).
  */}}
  {{- $dbUrl := include "agent-platform.postgresql.dsn" (dict "context" . "database" .Values.postgresql.auth.database) }}
  DATABASE_URL_SHIPWRIGHT_ADMIN: {{ $dbUrl | b64enc | quote }}
{{- end }}
{{- if and (eq .Values.auth.mode "google") (not .Values.auth.google.existingSecret) }}
  {{- /* Google OAuth client credentials — omitted when auth.google.existingSecret is set
       (the Deployment sources them from the caller-managed Secret via secretKeyRef). */}}
  GOOGLE_CLIENT_ID: {{ .Values.auth.google.clientId | b64enc | quote }}
  GOOGLE_CLIENT_SECRET: {{ .Values.auth.google.clientSecret | b64enc | quote }}
{{- end }}
{{- if and (eq .Values.auth.mode "okta") (not .Values.auth.okta.existingSecret) }}
  {{- /* Okta OIDC credentials — omitted when auth.okta.existingSecret is set
       (the Deployment sources them from the caller-managed Secret via secretKeyRef). */}}
  OKTA_ISSUER: {{ .Values.auth.okta.issuer | b64enc | quote }}
  OKTA_CLIENT_ID: {{ .Values.auth.okta.clientId | b64enc | quote }}
  OKTA_CLIENT_SECRET: {{ .Values.auth.okta.clientSecret | b64enc | quote }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Admin ServiceAccount.
*/}}
{{- define "agent-platform.admin.serviceaccount" -}}
{{- if and .Values.admin.enabled .Values.admin.serviceAccount.create }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ include "agent-platform.admin.serviceAccountName" . }}
  labels:
    {{- include "agent-platform.admin.labels" . | nindent 4 }}
  {{- with .Values.admin.serviceAccount.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Admin PodDisruptionBudget.
*/}}
{{- define "agent-platform.admin.pdb" -}}
{{- if and .Values.admin.enabled .Values.admin.podDisruptionBudget.enabled }}
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: {{ include "agent-platform.admin.fullname" . }}
  labels:
    {{- include "agent-platform.admin.labels" . | nindent 4 }}
spec:
  minAvailable: {{ .Values.admin.podDisruptionBudget.minAvailable }}
  selector:
    matchLabels:
      {{- include "agent-platform.admin.selectorLabels" . | nindent 6 }}
{{- end }}
{{- end }}
